import {chromeApi} from "./chrome-api/index.js";

export const browser = {
    api: chromeApi,
};
